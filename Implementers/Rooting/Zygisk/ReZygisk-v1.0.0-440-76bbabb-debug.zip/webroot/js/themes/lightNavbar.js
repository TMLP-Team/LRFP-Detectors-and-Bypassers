export function setLightNav() {
  document.getElementById('ni_home').classList.add('light_icon_mode')
  document.getElementById('ni_modules').classList.add('light_icon_mode')
  document.getElementById('ni_actions').classList.add('light_icon_mode')
  document.getElementById('ni_settings').classList.add('light_icon_mode')
}
